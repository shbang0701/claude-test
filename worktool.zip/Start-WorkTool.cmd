@echo off
chcp 65001 >nul
rem WorkTool 실행: PowerShell 7(pwsh)로 WorkTool-WPF.ps1을 띄운다. 콘솔 창은 최소화해 두고, 앱을 끄면 같이 닫힌다.
where pwsh >nul 2>nul || (echo PowerShell 7(pwsh^)이 필요합니다. & pause & exit /b 1)
rem 인터넷에서 받은 zip을 그대로 풀면 스크립트가 막힌다 (실행 정책). 그때는 zip 속성에서 차단 해제 후 다시 푼다
pwsh -NoProfile -Command "if (Get-Item -LiteralPath '%~dp0WorkTool-WPF.ps1' -Stream Zone.Identifier -ErrorAction SilentlyContinue) { exit 9 }"
if errorlevel 9 (echo 인터넷에서 받은 파일이라 막혀 있습니다. 받은 worktool.zip 우클릭 - 속성 - 차단 해제에 체크하고 다시 압축을 푸세요. & pause & exit /b 1)
rem start /min은 쓰지 않는다: 앱 창까지 최소화된 채 떠서, 복원하면 Windows 기본 크기가 된다
start "WorkTool" pwsh -NoProfile -STA -WindowStyle Minimized -File "%~dp0WorkTool-WPF.ps1"
